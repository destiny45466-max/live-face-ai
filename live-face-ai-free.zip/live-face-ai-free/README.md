# Live Face AI — free prototype

## What this prototype does
- Runs as a single static webpage.
- Lets the user select a photo from their phone.
- Animates the whole photo with a gentle CSS movement.
- Does not send the image to a server.

## What it does NOT do
- It does not animate mouth/lips or sync speech.
- It does not use the microphone.
- It is not a real-time AI avatar or a virtual camera.
- Realistic lip-sync requires a suitable model or service, which may have costs or usage limits.

## Test on your phone
1. Extract the ZIP on your phone or open `index.html` in a code editor/preview app that supports local HTML.
2. For a public HTTPS link, use a free static host such as GitHub Pages or Netlify Drop. Free-plan rules can change.
3. Upload `index.html` as the site content, then open the HTTPS URL on your phone.

## Publish using GitHub Pages (free option)
1. Sign in or create an account at https://github.com
2. Create a new public repository, for example `live-face-ai`.
3. Add `index.html` to the repository root.
4. In repository Settings -> Pages, choose deploy from branch, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish and open the URL shown in the Pages settings.

No API key or paid service is needed for this prototype.
